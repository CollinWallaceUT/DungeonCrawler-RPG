# ECE 312 - Lab 6 Write-Up

**Name:** Collin Wallace  
**EID:** cmw5342  
**Date:** 12/7/2025

---

## 1. Design Decisions (3-4 sentences)

Briefly describe your key design choices and rationale: 

For the most part I followed instructions provided in the ReadMe, TODOs and comments above each function. Those led me to structure my code in a modular way, seperating core logic and helper functions into distinct files to keep design easy to reuse. I made tests after each source code to ensure no leaks or bugs in my code along the way. For game.cpp, I chose a polling-based approach for handling imputs, and used well-defined interfaces between modules so their is clear control flow for tracking and modifications.

- **Overall implementations:** How did you make use of object-oriented concepts in your decision? 

I applied object-oriented design mainly through two inheritance hierarchies: one for characters and one for items. At the top level I defined a Character base class that stores shared state like name, HP, attack..., and declares virtual methods like calculateDamage(), takeDamage(), etc.

Specifically, how did you use inheritance and polymorphism (if you did) and how did it help or complicate the design over using a language like C? 

Both Player and Monster inherit from Character, and then each specific enemy type (Goblin, Skeleton, etc) inhereits from Monster and overrides behavior like getAttackMessage(). Polymorphism shows up in the combat loop, where the function only works with a Monster* and calls virtual methods; the correct subclass is chosen at runtime without extra logic. Similarly for Item base class holding common fields (name, description, etc) share a virtual DisplayInfo(), where Weapon, Armor, and Consumable all inherit from Item. Compared to writing this in C with structs, inheritance and polymorphism made it much easier to add new monsters or items without having to rewrite/change original logic. 

Draw a diagram showing the classes you used and their relationships to each other (subclass to superclass relationships specifically.) 

        Character 
        /       \
    Player      Monster
                /   |      \   
            Goblin Skeleton Ogre ...

       Item
    /   |   \
Weapon Armor Consumables

- **Memory management:** What strategy did you use to avoid leaks? Any particular challenges? 

I tried to avoid leaks by giving each dynamically allocations object a clear "owner" and cleaning up everything in that owner's destructor. Like Game owns Room* and Player* (deletes them in ~Game), and Player owns inventory Item* (deletes in ~Player), etc. The hardest part was avoiding double-deletes when items moved (like monster's loot table to a room), so I had to be careful to transfer ownership.

---

## 2. Testing & Debugging (2-3 sentences)

Describe your testing process and any major bugs you encountered:

For testing, I didn't use make test (mainly because I didn't think about using it, or know how to if I did). I made individual test files for each room and compiled them seperately after completing each source file, ensuring no memory leaks and successful implementation before moving forward. Once I reached game.cpp, I switched my testing process to running the game and testing each case myself. Thankfully, I didn't encounter any major bugs.

- **Testing approach:** What was your strategy beyond running `make test`?

Well I didn't use 'make test' so everything, but I did manual playthroughs and tested each source file with debug outputs throughout my code, testing each edge-case for each TODO after implementing and before moving forward.

- **Most difficult bug:** What was the hardest bug to find/fix and how did you solve it?

The hardest bug for me to find/fix was linking my files and folders when trying to implement and run my tests, and eventually when runnning the entire game. I don't really know the best approach with teminal or project file layout (or linking).

---

## 3. Implementation Challenges (2-3 sentences)

Which TODOs were most challenging and why? 

The TODOs in the game.cpp source code were challenging because it took a lot of backtracking to see what I did at each step, as it is the culmination of each piece of code. The loops in the run, process command, and combat TODOs were tricky too because it took a lot of manual playthrough style debugging.

1. **Hardest TODO:** game::combat


2. **Most time-consuming:** game::combat or game::run


3. **Most interesting:** monster.cpp (implementing each monster type -- goblin::goblin, etc)

---


## 4. Reflection (1-2 sentences)

What was the most valuable lesson from this lab?

The most valuable lesson from this lab was seeing how powerful object oriented design can be with inheritance and polymorphism. Seeing the virtual functions and the subclasses being chosen at runtime was also benefitial.

---

## Submission Checklist

- [ DONE ] All functionality completed
- [ DONE ] `make test` passes with no failures
    ^(Each of self made tests passed - didn't use "make test")
- [ DONE ] `make valgrind` shows no memory leaks
- [ DONE ] Game fully functional 
- [ DONE ] Code compiles without warnings (`-Wall -Wextra`)
- [ DONE ] This write-up completed
- [ DONE ] Optional Bonus attempted? (Yes/No): YES

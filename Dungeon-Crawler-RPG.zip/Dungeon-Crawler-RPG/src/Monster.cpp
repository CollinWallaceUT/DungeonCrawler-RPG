#include "Monster.h"
#include <iostream>

// ============================================================================
// Base Monster class
// ============================================================================

// TODO: Implement Monster constructor
// HINTS:
// - MUST call Character base constructor
// - Initialize experience_reward and gold_reward
// - Loot table starts empty automatically
//
Monster::Monster(const std::string& name, int hp, int attack, int defense,
                 int exp_reward, int gold_reward)
    : Character(name, hp, attack, defense),
      experience_reward(exp_reward), gold_reward(gold_reward) {
}


// TODO: Implement Monster destructor
// HINTS:
// - Deallocate any allocated memory 
// - Loop through loot_table vector and delete each Item*
// - Clear the vector after deleting items
//
Monster::~Monster() {
  //TODO: Delete all loot items
  for (size_t i = 0; i < loot_table.size(); i++) { 
    delete loot_table[i];
    }
  loot_table.clear();
}


// TODO: Override displayStats
// HINTS:
// - Show monster name and HP
// - Format: "MonsterName [HP: current/max]"
// - Keep it simple - monsters don't need detailed stats display
//
void Monster::displayStats() const {
    // TODO: Display monster stats
    std::cout << getName() << " [HP: " << getCurrentHP() << "/" << getMaxHP() << "]" << std::endl;
    
}


// TODO: Implement addLoot
// HINTS:
// - Check if item pointer is not NULL
// - Add item to loot_table vector using push_back()
//
void Monster::addLoot(Item* item) {
    // TODO: Add item to loot table
    if (item != NULL) {
      loot_table.push_back(item);
      }
}


// TODO: Implement dropLoot
// HINTS:
// - Create a copy of the loot_table vector
// - Clear the original loot_table (transfer ownership to caller!)
// - Return the copy
// - This is important: caller now owns the items and must delete them
//
std::vector<Item*> Monster::dropLoot() {
    // TODO: Return loot and transfer ownership
    std::vector<Item*> dropped = loot_table;
    if (!dropped.empty()) {
      std::cout << "The " << getName() << " dropped:\n";
      
      for (size_t i = 0; i < dropped.size(); i++) {
        if (dropped[i] != NULL) {
          std::cout << "  - " << dropped[i]->getName() << "\n";
          }
        }
      std::cout << "Use pickup <item> to pick it up.\n";
      
      } else {
        std::cout << "The " << getName() << " dropped no items.\n";
        }
      
    loot_table.clear();
    return dropped;
}


// TODO: Implement getAttackMessage (base version)
// HINTS:
// - Return default attack message
// - Format: "MonsterName attacks!"
// - Use getName() to get monster's name
//
std::string Monster::getAttackMessage() const {
    // TODO: Return attack message
    return getName() + " attacks!";
}


// ============================================================================
// Goblin - Weak but common enemy
// ============================================================================

// TODO: Implement Goblin constructor
// HINTS:
// - Call Monster constructor with these stats:
//   * Name: "Goblin"
//   * HP: 30
//   * Attack: 5
//   * Defense: 2
//   * Experience: 10
//   * Gold: 5
// - Add a small potion to loot table
// - Example: addLoot(new Consumable("Small Potion", "Restores 10 HP", 10));
//
Goblin::Goblin() 
    : Monster("Goblin", 30, 5, 2, 10, 5) {
    // TODO: Add loot items
    addLoot(new Consumable("Small Potion", "Restores 10 HP", 10)); 
}


// TODO: Override getAttackMessage for Goblin
// HINTS:
// - Return goblin-specific attack message
// - Example: "The goblin swipes at you with its rusty dagger!"
//
std::string Goblin::getAttackMessage() const {
    // TODO: Return goblin attack message
    return "The goblin swipes at you with its rusty dagger!";
}


// ============================================================================
// Skeleton - Undead warrior
// ============================================================================

// TODO: Implement Skeleton constructor
// HINTS:
// - Call Monster constructor with these stats:
//   * Name: "Skeleton"
//   * HP: 40
//   * Attack: 8
//   * Defense: 4
//   * Experience: 20
//   * Gold: 10
// - Add an old sword to loot table
//
Skeleton::Skeleton()
    : Monster("Skeleton", 40, 8, 4, 20, 10) {
    // TODO: Add loot items
    addLoot(new Weapon("Wooden Bow", "A simple wooden bow from a single piece of wood and string. ", 4));
}


// TODO: Override getAttackMessage for Skeleton
// HINTS:
// - Return skeleton-specific attack message
// - Example: "The skeleton rattles its bones and slashes with a sword!"
//
std::string Skeleton::getAttackMessage() const {
    // TODO: Return skeleton attack message
    return "The skeleton creakes as it draws its bow and fires a jagged arrow!";
}


// ============================================================================
// Dragon - Boss enemy with special ability
// ============================================================================

// TODO: Implement Dragon constructor
// HINTS:
// - Call Monster constructor with these stats:
//   * Name: "Dragon"
//   * HP: 150
//   * Attack: 20
//   * Defense: 10
//   * Experience: 100
//   * Gold: 50
// - Add legendary loot:
//   * Dragon Slayer sword (damage +10)
//   * Dragon Scale Armor (defense +8)
//   * Greater Health Potion (heals 100 HP)
//
Dragon::Dragon()
    : Monster("Dragon", 150, 20, 10, 300, 50) {
    // TODO: Add legendary loot items
    //Legendary loot given to DungeonMaster - No point giving it to the dragon 
    //because you win if you beat him.
    addLoot(new Armor("Victory Pants", "Congragulations hero, you've earned it!", 5));
}


// TODO: Override getAttackMessage for Dragon
// HINTS:
// - Return dragon-specific attack message
// - Example: "The dragon breathes fire at you!"
//
std::string Dragon::getAttackMessage() const {
    // TODO: Return dragon attack message
    return "The dragon breathes fire at you!";
}


// TODO: Override calculateDamage for Dragon
// HINTS:
// - Call Monster::calculateDamage() to get base damage
// - Add bonus fire damage (+5)
// - Return total damage
// - This makes the dragon hit harder than other monsters!
//
int Dragon::calculateDamage() const {
    // TODO: Calculate damage with fire bonus
    int base = Monster::calculateDamage();
    return base + 5; //bonus fire damage
}

// ============================================================================
// Ogre - Tough but slow enemy (high HP, low Damage)
// ============================================================================

Ogre::Ogre()
    : Monster("Ogre", 110, 6, 4, 40, 15) {
      // High HP, low attack
      addLoot(new Armor("Onion Tunic", "Made from enchanted onion skins and swamp linen. It has many layers and an even stronger smell.", 5));
      addLoot(new Consumable("Large Potion", "A strong potion that restores 25 HP.", 25));
}

std::string Ogre::getAttackMessage() const {
    return "The ogre swings its massive club in a slow, crushing arc!";
}

// ============================================================================
// Ghost - Elusive undead (high evasion simulated with high defense)
// ============================================================================

Ghost::Ghost()
    : Monster("Ghost", 45, 10, 8, 55, 20) {
    //Higher defense makes it harder to damage (acts like evasion)
    addLoot(new Consumable("Stay Puft Mallows", "A bag of ghostly-sweet marshmallows that somehow stay perfectly fresh.", 20));
}
    
std::string Ghost::getAttackMessage() const {
    return "The ghost phases through you with a chilling touch!";
}

// ============================================================================
// Wizard - Fragile but dangerous ranged attacker
// ============================================================================

Wizard::Wizard()
    : Monster("Wizard", 85, 15, 3, 60, 30) {
    addLoot(new Armor("Invisibility Cloak", "An ancient cloak passed down through generations of wizards. One of the three Deathly Hallows.", 8));
    addLoot(new Consumable("Mana Potion", "A strange brew that restores 30 HP.", 30));
}

std::string Wizard::getAttackMessage() const {
    return "The wizard hurls a bolt of arcane energy from afar! Screaming AVADA KEDAVRA!";
}

// ============================================================================
// Mimic - Treasure chest monster
// ============================================================================

Mimic::Mimic()
    : Monster("Mimic", 80, 14, 7, 60, 40) {
    // Decent HP, strong bite, good defense, nice rewards
    addLoot(new Weapon("Tongue Whip", "A slimy organic whip that somehow counts as a weapon. Slightly gross, surprisingly effective.", 7));
    addLoot(new Armor("Chest Plate", "A breastplate literally made from mimic chest wood. Still smells like old coins and fear.", 6));
    addLoot(new Consumable("Chocolate coins", "A handful of hard, coin shaped candies found rattling around inside the mimic. Probably not FDA approved.", 35));
}

std::string Mimic::getAttackMessage() const {
    return "The mimic snaps its wooden jaws as the chest comes to life!";
}

// ============================================================================
// DungeonMaster - Elite guardian before the dragon
// ============================================================================

DungeonMaster::DungeonMaster()
    : Monster("DungeonMaster", 110, 18, 9, 85, 40) {
    // Strong weapon and armor to prepare for the dragon fight
    addLoot(new Weapon("Dragon Slayer", "Legendary sword forged in dragonfire.", 12));
    addLoot(new Armor("Diamond Armor", "Gleaming plates of enchanted diamond that shrug off dragonfire and brutal strikes.", 10));
    addLoot(new Consumable("Enchanted Golden Apple", "A radiant 'E-Gap' infused with ancient magic that rapidly restores 100 HP.", 100));
}

std::string DungeonMaster::getAttackMessage() const {
    return "The DungeonMaster commands the battlefield with a crushing blow!";
    

}

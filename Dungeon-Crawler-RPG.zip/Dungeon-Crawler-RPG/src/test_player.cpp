#include <iostream>
#include "Player.h"

int main() {
    std::cout << "===== PLAYER CREATION TEST =====\n";
    Player hero("Alice");
    hero.displayStats();

    std::cout << "\n===== DAMAGE + HP TEST =====\n";
    hero.takeDamage(20);
    hero.displayStats();

    std::cout << "\n===== INVENTORY ADD / DISPLAY TEST =====\n";
    hero.addItem(new Weapon("Sword", "Sharp blade", 5));
    hero.addItem(new Consumable("Potion", "Heals 20 HP", 20));
    hero.displayInventory();

    std::cout << "\n===== REMOVE ITEM (CASE-INSENSITIVE) TEST =====\n";
    hero.removeItem("pOtIoN"); //Case insensitive
    hero.displayInventory();

    std::cout << "\n===== ADD MULTIPLE ITEMS FOR EQUIP TEST =====\n";
    hero.addItem(new Weapon("Sword", "Backup sword", 5));  
    hero.addItem(new Armor("Chainmail", "Strong armor", 3));

    std::cout << "\n===== EQUIP WEAPON / ARMOR TEST =====\n";
    hero.equipWeapon("sword");
    hero.equipArmor("chainmail");
    hero.displayStats();

    std::cout << "\n===== DAMAGE CALCULATION TEST =====\n";
    int dmg = hero.calculateDamage();
    std::cout << "Calculated Damage: " << dmg << "\n"; //Should include weapon bonus

    std::cout << "\n===== LEVEL-UP TEST =====\n";
    hero.displayStats();
    hero.gainExperience(100);  // Should trigger level up
    hero.displayStats();

    std::cout << "\n===== ALL TESTS COMPLETE =====\n";
    return 0;
}
#include "Game.h"
#include <iostream>
#include <sstream>
#include <algorithm>
#include <cctype>

// TODO: Implement Game constructor
Game::Game() : player(NULL), current_room(NULL), 
               game_over(false), victory(false) {
}


// TODO: Implement Game destructor
Game::~Game() {
    // TODO: Clean up player and all rooms
    if (player != NULL) {
      delete player;
      player = NULL;
      }
    
    for (std::map<std::string, Room*>::iterator it = world.begin(); it != world.end(); it++) {
      delete it->second;
      }
    world.clear();
}


// TODO: Implement initializeWorld
// HINTS:
// - Create all rooms with new
// - Add each room to world using addRoom()
// - Connect rooms using connectRooms()
// - Add monsters to appropriate rooms using room->setMonster()
// - Add items to rooms using room->addItem()
// - Set current_room to starting room (entrance)
//
// SUGGESTED WORLD LAYOUT:
//                [Dragon Chamber]
//                     |
//                 [Throne Room]
//                     |
//                 [Great Hall] - [Ancient Library]
//                     |
//      [Treasury] - [Guard Post]
//                     |                  
//                  [Hallway] - [Armory]
//                     |
//                 [Entrance]
//
// MONSTERS:
// - Hallway: Goblin
// - Armory: Skeleton
// - Guard Post: Troll
// - Treasury: Mimic
// - Great Hall: Ghost
// - Ancient Library: Wizard
// - Throne Room: DungeonMaster
// - Dragon Chamber: Dragon (boss!)
//
// ITEMS:
// - Entrance: Small Potion
// - Armory: Old Sword
// - Treasury: Health Potion
// - Guard Post: Guard Shield
// - Great Hall: Feast Rations
// - Library: Apprentice Wand
//
void Game::initializeWorld() {
    // TODO: Create rooms
    // Room* entrance = new Room("Dungeon Entrance", "A dark stone corridor...");
    Room* entrance = new Room("Entrance", "You stand at the entrance of a dark dungeon. Cold air seeps from within.");
    
    Room* hallway = new Room("Hallway", "A narrow stone hallway lit by flickering torches. You hear distant growls.");
    
    Room* armory = new Room("Armory", "Rusty weapons and dented armor line the walls. Dust covers everything.");
    
    Room* treasury = new Room("Treasury", "A small chamber glitters with scattered coins and chests.");
    
    Room* guard_post = new Room("Guard Post", "A cramped room where dungeon guards once kept watch over the halls.");
    
    Room* great_hall = new Room("Great Hall", "A wide chamber lined with torn banners and long-abandoned tables.");
    
    Room* library = new Room("Ancient Library", "Towering shelves of crumbling tomes and scrolls surround you. Dust motes drift through the faint, eerie light." );
    
    Room *throne = new Room("Throne Room", "A vast, ominous chamber with a towering throne. The air smells of smoke.");
    
    Room *chamber = new Room("Dragon Chamber", "An immense cavern scorched black by ancient flames. Molten cracks glow beneath your feet and the air vibrates with a deep, rumbling breath.");
    
    // TODO: Add rooms to world
    addRoom(entrance);
    addRoom(hallway);
    addRoom(armory);
    addRoom(treasury);
    addRoom(guard_post);
    addRoom(great_hall);
    addRoom(library);
    addRoom(throne);
    addRoom(chamber);
    
    // TODO: Connect rooms bidirectionally
    connectRooms("Entrance", "north", "Hallway");
    connectRooms("Hallway", "north", "Guard Post");
    connectRooms("Hallway", "east", "Armory");
    connectRooms("Guard Post", "north", "Great Hall");
    connectRooms("Guard Post", "west", "Treasury");
    connectRooms("Great Hall", "north", "Throne Room");
    connectRooms("Great Hall", "east", "Ancient Library");
    connectRooms("Throne Room", "north", "Dragon Chamber");
    
    // TODO: Add monsters
      hallway->setMonster(new Goblin());
      armory->setMonster(new Skeleton());
      treasury->setMonster(new Mimic());
      guard_post->setMonster(new Ogre());
      great_hall->setMonster(new Ghost());
      library->setMonster(new Wizard());
      throne->setMonster(new DungeonMaster());
      chamber->setMonster(new Dragon());
    
    // TODO: Add items
    entrance->addItem(new Consumable("Small Potion", "A small vial that restores a little health.", 10));
    armory->addItem(new Weapon("Old Sword", "A brittle blade, but still sharp enough.", 3));
    guard_post->addItem(new Armor("Metal Shield", "A heavy shield bearing the crest of the dungeon's overlord.", 4));
    treasury->addItem(new Consumable("Big Pot", "A bright blue potion that restores a good amount of health.", 50));
    great_hall->addItem(new Consumable("Feast Rations", "Stale rations from an ancient feast, but still edible. Restores some health.", 15));
    library->addItem(new Weapon("Elder Wand", "An ancient wand Death fashioned from an elder tree. The wand chooses the wizard, it's not always clear why.", 9));
    
    // TODO: Set starting room
    current_room = entrance;
    current_room->markVisited();
}


// TODO: Implement createStartingInventory
// HINTS:
// - Give player starting weapon: Rusty Dagger (damage +2)
// - Give player starting food: Bread (heals 5 HP)
// - Use: player->addItem(new Weapon(...))
//
void Game::createStartingInventory() {
    // TODO: Give player starting items
    player->addItem(new Weapon("Rusty Dagger", "A dull dagger, but better than nothing.", 2));
    player->addItem(new Consumable("Bread", "A stale loaf that restores a little health.", 5));
}


// TODO: Implement addRoom
// HINTS:
// - Check if room pointer is not NULL
// - Add to world map using room's name as key
// - Use: world[room->getName()] = room
//
void Game::addRoom(Room* room) {
    // TODO: Add room to world map
    if (room != NULL) {
      world[room->getName()] = room;
      }
      
      
}


// TODO: Implement connectRooms
// HINTS:
// - Look up both rooms in world map
// - If both exist:
//   - Add forward direction: room1->addExit(direction, room2)
//   - Determine reverse direction:
//     * north ↔ south
//     * east ↔ west
//   - Add reverse direction: room2->addExit(reverse, room1)
//
void Game::connectRooms(const std::string& room1_name, const std::string& direction, const std::string& room2_name) {
    // TODO: Connect rooms bidirectionally
    std::map<std::string, Room*>::iterator it1 = world.find(room1_name);
    std::map<std::string, Room*>::iterator it2 = world.find(room2_name);
    
    if (it1 == world.end() || it2 == world.end()) {
      std::cerr << "Error: cannot connect rooms '" << room1_name << "' and '" << room2_name << "'.\n";
      return;
      }
    
    Room* r1 = it1->second;
    Room* r2 = it2->second;
    
    r1->addExit(direction, r2);
    
    std::string rev;
    if (direction == "north") {
      rev = "south";
      }
    else if (direction == "south") {
      rev = "north";
      }
    else if (direction == "east") {
      rev = "west";
      }
    else if (direction == "west") {
      rev = "east";
      }
    else {
      return;
      }
    
    r2->addExit(rev, r1);
}


// TODO: Implement run - main game loop
// HINTS:
// - Print welcome message and game title
// - Get player name from input 
// - Create player: player
// - Call initializeWorld()
// - Call createStartingInventory()
// - Display starting room
// - Mark starting room as visited
// - Main loop: 
//   - Print prompt: "> "
//   - Get command (use std::getline)
//   - Convert to lowercase (use std::transform)
//   - Call processCommand()
//   - Check victory condition
//   - Check defeat condition (player dead)
//
void Game::run() {
    // TODO: Implement main game loop
    std::cout << "<==============================================>\n";
    std::cout << "                 DUNGEON CRAWLER                \n";
    std::cout << "<==============================================>\n";
    
    std::cout << "What is your name, hero? ";
    std::string name;
    std::getline(std::cin, name);
    if (name.empty()) {
      name = "Hero";
      }
    
    player = new Player(name);
    
    initializeWorld();
    createStartingInventory();
    
    std::cout << "\nWelcome, " << name << "! Your adventure begins...\n\n";
    
    std::cout << "Use commands from this list to control your hero!\n";
    help();
    
    current_room->display();
    std::cout << "To start exploring, try using controls like:\n";
    std::cout << "  - 'pickup small potion', to pick up the item in the room.\n";
    std::cout << "  - 'equip rusty dagger', to equip the weapon from your inventory.\n";
    std::cout << "  - 'go north', to head out of this room and into the next!\n";
    
    while (!game_over) {
      if (!player->isAlive()) {
        std::cout << "\nYou have fallen in the dungeon...\n";
        game_over = true;
        break;
        }
      
      if (victory) {
        std::cout << "\nYou have defeated the Dragon and cleared the dungeon!\n";
        std::cout << "Conragulations, " << name << "!\n";
        game_over = true;
        break;
        }
        
      if (current_room != NULL) {
        static bool goblin_hint_shown = false;
        
        if (!goblin_hint_shown && current_room->getName() == "Hallway" && current_room->getMonster() != NULL) {
          std::cout << "Try using 'attack' to start a battle against the goblin!\n";
          goblin_hint_shown = true;
          }
        }
      
      std::cout << "\n> ";
      std::string line;
      std::getline(std::cin, line);
      
      //to lowercase
      for (std::string::iterator it = line.begin(); it != line.end(); it++) {
        *it = static_cast<char> (std::tolower(static_cast<unsigned char>(*it)));
        }
      
      if (line.empty()) {
        continue;
        }
        
      processCommand(line);
      }
    
    std::cout << "\nGame over.\n";
}


// TODO: Implement processCommand
// HINTS:
// - Parse command into verb and object
// - Extract first word as verb
// - Rest of line is object
// - Dispatch to appropriate method based on verb:
//   * "go" or "move" → move(object)
//   * "look" or "l" → look()
//   * "attack" or "fight" → attack()
//   * "pickup" or "get" or "take" → pickupItem(object)
//   * "inventory" or "i" → inventory()
//   * "use" → useItem(object)
//   * "equip" or "e" → equip(object)
//   * "stats" → player->displayStats()
//   * "help" or "h" or "?" → help()
//   * "quit" or "exit" → set game_over to true
//
void Game::processCommand(const std::string& command) {
    // TODO: Parse and dispatch command
    std::istringstream iss(command);
    std::string verb;
    iss >> verb;
    
    std::string object;
    std::getline(iss, object);
    if (!object.empty() && object[0] == ' ') {
      object.erase(0, 1);
      }
    
    if (verb == "go" || verb == "move") {
      if (object.empty()) {
        std::cout << "Go where?\n";
        } else {
        move(object);
        }
      }
    else if (verb == "look" || verb == "l") {
      look();
      }
    else if (verb == "attack" || verb == "fight") {
      attack();
      }
    else if (verb == "pickup" || verb == "get" || verb == "take") {
      if (object.empty()) {
        std::cout << "Pick up what?\n";
        }
      else {
        pickupItem(object);
        }
      }
    else if (verb == "inventory" || verb == "i") {
      inventory();
      }
    else if (verb == "use") {
      if (object.empty()) {
        std::cout << "Use what?\n";
        }
      else {
        useItem(object);
        }
      }
    else if (verb == "equip" || verb == "e") {
      if (object.empty()) {
        std::cout << "Equip what?\n";
        }
      else {
        equip(object);
        }
      }
    else if (verb == "stats") {
      player->displayStats();
      }
    else if (verb == "help" || verb == "h" || verb == "?") {
      help();
      }
    else if (verb == "quit" || verb == "exit") {
      game_over = true;
      }
    else {
      std::cout << "I don't understand that command.\n";
      }      
      
}


// TODO: Implement move
// HINTS:
// - Check if monster blocks path (current_room->hasMonster())
// - If blocked, print message and return
// - Get exit in specified direction
// - If exit exists:
//   - Update current_room
//   - Display new room
//   - Mark as visited
// - Otherwise print error: "You can't go that way!"
//
void Game::move(const std::string& direction) {
    // TODO: Move to adjacent room
    if (current_room->hasMonster()) {
      std::cout << "A " << current_room->getMonster()->getName() << " blocks your path! Defeat it first.\n";
      return;
      }
    
    Room* next = current_room->getExit(direction);
    if (next == NULL) {
      std::cout << "You can't go that way!\n";
      return;
      }
    
    current_room = next;
    current_room->markVisited();
    std::cout << "\n";
    current_room->display();

}


// TODO: Implement look
// HINTS:
// - Simply display current room
//
void Game::look() {
    // TODO: Display current room
    current_room->display();
}


// TODO: Implement attack
// HINTS:
// - Check if monster in room
// - If no monster, print message and return
// - If monster present, call combat()
//
void Game::attack() {
    // TODO: Attack monster in room
    if (!current_room->hasMonster()) {
      std::cout << "There is nothing here to attack.\n";
      return;
      }
    Monster* m = current_room->getMonster();
    combat(m);
}


// TODO: Implement combat
// HINTS:
// - Print "=== COMBAT BEGINS ==="
// - Combat loop: while both player and monster are alive
//   - Prompt for player action: attack/use <item>/flee
//   - If attack:
//     * Calculate player damage
//     * Monster takes damage
//     * If monster dead:
//       - Print victory
//       - Player gains exp and gold
//       - Get loot from monster
//       - Add loot to current room
//       - Check if Dragon 
//       - Clear monster from room
//       - Break from loop
//   - If use:
//     * Extract item name from command
//     * Call player->useItem()
//   - If flee:
//     * Print message and break
//   - Monster turn (if alive):
//     * Print attack message
//     * Calculate monster damage
//     * Player takes damage
// - Print "=== COMBAT ENDS ==="
//
void Game::combat(Monster* monster) {
    // TODO: Implement turn-based combat
    std::cout << "<=============== COMBAT BEGINS! ===============>\n";
    
    while (player->isAlive() && monster->isAlive()) {
    
    std::cout << "Choose action (attack / heal / flee): ";
    std::string line;
    std::getline(std::cin, line);
      
    //to lowercase
    for (std::string::iterator it = line.begin(); it != line.end(); it++) {
      *it = static_cast<char> (std::tolower(static_cast<unsigned char>(*it)));
      }
    
    std::istringstream iss(line);
    std::string verb;
    iss >> verb;
    
    std::string obj;
    std::getline(iss, obj);
    if (!obj.empty() && obj[0] == ' ') {
      obj.erase(0, 1);
      }
    if (verb == "attack") {
      //Check if monster is ghost, and add miss chance -- 40% 
      bool isGhost = (dynamic_cast<Ghost*>(monster) != NULL);
      int dmg = 0;
      
      if (isGhost) {
        int roll = std::rand() % 100;
        if (roll < 55) {
          std::cout << "\nYour attack passes right through the ghost! You deal no damage!\n";
          } else {
      dmg = player->calculateDamage();
      std::cout << "\nYou strike the " << monster->getName() << " for " << dmg << " damage!\n";
      monster->takeDamage(dmg);
        } 
      } else {
        
      // Normal attack -- non-ghost monsters
      dmg = player->calculateDamage();
      std::cout << "\nYou strike the " << monster->getName() << " for " << dmg << " damage!\n";
      monster->takeDamage(dmg);
      }
      
      if (!monster->isAlive()) {
        std::cout << "You have slain the " << monster->getName() << "!\n";
        
        player->gainExperience(monster->getExperienceReward());
        player->addGold(monster->getGoldReward());
        
        std::vector<Item*> loot = monster->dropLoot();
        for (size_t i = 0; i < loot.size(); i++) { 
          current_room->addItem(loot[i]);
          }
        
        if (dynamic_cast<Dragon*>(monster) != NULL) {
          victory = true;
          }
        
        current_room->clearMonster();
        break;
        }
      }
    else if (verb == "heal") {
      if (obj.empty()) {
        std::cout << "\nThis time type 'heal <item>'\n";
        std::cout << "Which consumable would you like to use?\n";
        player->listConsumables();
        continue;
        }
      player->useItem(obj);
      }
    else if (verb == "flee") {
      std::cout << "\nYou flee from combat!\n";
      break;
      }
    else {
      std::cout << "Magikarp used Splash!\n";
      std::cout << "But nothing happened...\n";
      continue;
      }
    
    if (monster->isAlive()) {
      int mdmg = monster->calculateDamage();
      std::cout << monster->getAttackMessage() << "\n";
      std::cout << "It hits you for " << mdmg << " damage!\n";
      player->takeDamage(mdmg);
      }
    }
    
    std::cout << "<================ COMBAT ENDS! ================>\n";

}


// TODO: Implement pickupItem
// HINTS:
// - Get item from current room
// - If exists:
//   - Add to player inventory
//   - Remove from room (ownership transfer!)
// - Otherwise print error
//
void Game::pickupItem(const std::string& item_name) {
    // TODO: Pick up item from room
    Item* item = current_room->getItem(item_name);
    if (item == NULL) {
      std::cout << "You don't see a '" << item_name << "' here.\n";
      return;
      }
    
    player->addItem(item);
    current_room->removeItem(item_name);
    std::cout << "You pick up the " << item->getName() << ".\n";
}


// TODO: Implement inventory
//
void Game::inventory() {
    // TODO: Display player inventory
    player->displayInventory();
}


// TODO: Implement useItem
// HINTS:
// - Call player->useItem(item_name)
//
void Game::useItem(const std::string& item_name) {
    // TODO: Use item from inventory
    player->useItem(item_name);
}


// TODO: Implement equip
// HINTS:
// - Get item from player inventory
// - Check if item exists
// - Check item type:
//   - If "Weapon": call player->equipWeapon()
//   - If "Armor": call player->equipArmor()
//   - Otherwise: print error (can't equip consumables)
//
void Game::equip(const std::string& item_name) {
    // TODO: Equip weapon or armor
    Item* item = player->getItem(item_name);
    if (item == NULL) {
      std::cout << "You don't have a '" << item_name << "'.\n";
      return;
      }
    
    std::string type = item->getType();
    
    if (type == "Weapon") {
      player->equipWeapon(item_name);
      }
    else if (type == "Armor") {
      player->equipArmor(item_name);
      }
    else {
      std::cout << "You can't equip that.\n";
      return;
      }
    
}


// TODO: Implement help
// HINTS:
// - Print all available commands with descriptions
// - Format nicely with headers
// - Commands:
//   * go <direction> - Move
//   * look - Look around
//   * attack - Attack monster
//   * pickup <item> - Pick up item
//   * inventory - Show inventory
//   * use <item> - Use consumable
//   * equip <item> - Equip weapon/armor
//   * stats - Show character stats
//   * help - Show this help
//   * quit - Exit game
//
void Game::help() {
    // TODO: Display help message
    std::cout << "<==================== HELP ====================>\n";
    std::cout << "go <direction>   - Move north/south/east/west\n";
    std::cout << "look             - Look around the current room\n";
    std::cout << "attack           - Attack the monster in the room\n";
    std::cout << "pickup <item>    - Pick up an item in the room\n";
    std::cout << "inventory        - Show your inventory\n";
    std::cout << "use <item>       - Use a consumable item\n";
    std::cout << "equip <item>     - Equip a weapon or armor\n";
    std::cout << "stats            - Show your character stats\n";
    std::cout << "help             - Show this help message\n";
    std::cout << "quit             - Exit the game\n\n";
}

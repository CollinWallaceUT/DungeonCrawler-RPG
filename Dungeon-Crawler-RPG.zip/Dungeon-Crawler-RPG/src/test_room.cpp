#include <iostream>
#include "Room.h"
#include "Monster.h"
#include "Item.h"

int main() {
    // Test basic room creation and display
    Room entrance("Entrance", "A dark corridor");
    entrance.display();

    // Test exits between rooms
    Room room1("Room 1", "First room");
    Room room2("Room 2", "Second room");

    room1.addExit("north", &room2);
    room2.addExit("south", &room1);

    room1.display();

    // Test getExit
    Room* next = room1.getExit("north");
    if (next) {
        next->display();
    }
    else {
        std::cout << "No exit found!" << std::endl;
    }

    // Test items and monster assignment
    Room room("Armory", "Weapons everywhere");
    room.addItem(new Weapon("Sword", "Sharp", 5));
    room.setMonster(new Goblin());

    room.display();

    // Monster presence check
    if (room.hasMonster()) {
        std::cout << "Monster present!" << std::endl;
    }

    return 0;
}